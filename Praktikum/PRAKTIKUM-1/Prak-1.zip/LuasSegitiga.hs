module LuasSegitiga where

luasSegitiga :: Float -> Float -> Float
luasSegitiga a b = a * b /2
