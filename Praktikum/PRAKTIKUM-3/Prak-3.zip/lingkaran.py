r = int(input())
if r <= 0:
    print("Jari-jari harus > 0")
else:
    print("%.2f" % (3.1415*r*r))
